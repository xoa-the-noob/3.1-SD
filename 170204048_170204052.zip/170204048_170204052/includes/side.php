<div class="panel panel-default sidebar-menu">
    <div class="panel-heading">
        <h3 class="panel-title">ORAL</h3>
    </div>
    
    <div class="panel-body">
        <ul class="nav nav-pills nav-stacked category-menu">
            
            <li><a href="#">Analgesic</a></li>
            <li><a href="#">Antipyretics</a></li>
            <li><a href="#">Antibiotics</a></li>
            <li><a href="#">Antihistamine</a></li>
            <li><a href="#">Acidity</a></li>
            <li><a href="#">Asthma</a></li>
            <li><a href="#">Sedatives</a></li>
            <li><a href="#">Antiprotozoal</a></li>
            
        </ul>
    </div>
    
</div>


<div class="panel panel-default sidebar-menu">
    <div class="panel-heading">
        <h3 class="panel-title">TOPICAL</h3>
    </div>
    
    <div class="panel-body">
        <ul class="nav nav-pills nav-stacked category-menu">
            
            <li><a href="#">Ointments</a></li>
            <li><a href="#">Antiseptic</a></li>
            <li><a href="#">Cream</a></li>
            <li><a href="#">Lotion</a></li>
            <li><a href="#">Spray</a></li>
            <li><a href="#">Gel</a></li>
            
        </ul>
    </div>
    
</div>

<div class="panel panel-default sidebar-menu">
    <div class="panel-heading">
        <h3 class="panel-title">DROPS</h3>
    </div>
    
    <div class="panel-body">
        <ul class="nav nav-pills nav-stacked category-menu">
            
            <li><a href="#">Ear drops</a></li>
            <li><a href="#">Eye drops</a></li>
            <li><a href="#">Nasal drops</a></li>
            
            
        </ul>
    </div>
    
</div>