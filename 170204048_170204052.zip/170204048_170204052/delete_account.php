<div class="box">

    <div class="box-header">

        <center>

            <h2>Are you sure you want to Delete your account? </h2>
            <div class="text-center">

              <form action="customer_account.php" method="post" enctype="multipart/form-data">

                  <div class="text-center">

                      <button type="submit" name="delete" class="btn btn-primary">

                      <i class="fa fa-user-md"></i> Yes

                      </button>

                  </div>

              </form>

            </div>

        </center>
        <?php

         ?>

    </div>

</div>
