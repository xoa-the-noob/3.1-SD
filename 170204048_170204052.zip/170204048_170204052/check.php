<?php
session_start();

header('location:cart.php');
 ?>
