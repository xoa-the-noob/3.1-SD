<div class="box">

    <div class="box-header">

        <center>

            <h2> Change password </h2>

        </center>
                <form action="customer_account.php" method="post" enctype="multipart/form-data">

                    <div class="form-group">

                        <label>Set a new password : </label>

                        <input type="password" class="form-control" name="password1" required>

                    </div>

                    <div class="form-group">

                        <label>New password :</label>

                        <input type="password"  class="form-control" name="password2"  required>

                    </div>

                    <div class="text-center">

                        <button type="submit" name="change_pass" class="btn btn-primary">

                        <i class="fa fa-user-md"></i> Change Password

                        </button>

                    </div>

                </form>
    </div>

</div>
